import java.io.File;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.DosFileAttributes;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.swing.filechooser.FileSystemView;
/*       File[] drives = File.listRoots();
if (drives != null && drives.length > 0) {
    for (File aDrive : drives) {
        System.out.println("Drive Letter: " + aDrive);
        System.out.println("\tType: " + fsv.getSystemTypeDescription(aDrive));
        System.out.println("\tTotal space: " + aDrive.getTotalSpace());
        System.out.println("\tFree space: " + aDrive.getFreeSpace());
        System.out.println("");
        System.out.println();
    }
}
/*    
*
*
*Connection connection = new getConnection();
Statement statement = connection.createStatement();

for (String query : queries) {
statement.addBatch(query);
}
statement.executeBatch();
statement.close();
connection.close();
*
*
*

*/
/**
 * 
 */

/**
 * @author harikrishna.trivedi
 *
 */
public class SystemAudit {

	/**
	 * @param args
	 */
	static FileSystemView fsv = FileSystemView.getFileSystemView();
	static Connection connection;
	static Statement statement;
	static PreparedStatement pStatement;
	static String hostname="unknown";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	String hostname = "Unknown";

		  try {
	        Class.forName("org.postgresql.Driver");
	        connection = DriverManager.getConnection("jdbc:postgresql://192.168.0.223:5432/SystemAudit","postgres", "root");
	        statement = connection.createStatement();

 		    InetAddress addr;
 		    addr = InetAddress.getLocalHost();
 		    hostname = addr.getHostName();
 		    
 		    System.out.println(hostname.toString());
 		    ResultSet rs=statement.executeQuery("select deviceid from \"DeviceInfo\" where deviceid='"+hostname+"'");
 		    if(!rs.next()){
 		    	statement.execute("insert into \"DeviceInfo\" (deviceid)values('"+hostname+"')");
 		    }
 		    statement.close();
 		   	pStatement=connection.prepareStatement("insert into \"fileinfo\" (deviceid,path,size) values (?,?,?)");
 		   	
 		   	FileSystemView fsv = FileSystemView.getFileSystemView();
 		   	File drive_list[]=File.listRoots();  //lists all drives
 	        for(File drive : drive_list) {
 	        	if(fsv.getSystemTypeDescription(drive).equalsIgnoreCase("Local Disk") ){//&& !drive.toString().equalsIgnoreCase("C:\\")) {
 	            	list(drive);
 	            }
 	        }
 	        pStatement.executeBatch();
 	        pStatement.close();
 	        connection.close();
 	        System.out.println("DONE Successfully");
	      	} catch (UnknownHostException ex) {
	 		    System.out.println("Hostname can not be resolved");
	 		}catch (Exception e) {
	         e.printStackTrace();
	         System.err.println(e.getClass().getName()+": "+e.getMessage());
	         System.exit(0);
	 		}

	}

	static void list(File f){
        if (f.isFile()){
        	try {
        	//statement.addBatch("insert into \"fileinfo\" (deviceid,path,size) values ('"+hostname+"','"+f.getAbsolutePath()+"',"+String.format("%.3f", (double)f.length()/1024/1024)+")");
        	pStatement.setString(1, hostname);
        	pStatement.setString(2, f.getAbsolutePath());
        	pStatement.setDouble(3, f.length());
        	pStatement.addBatch();
            //System.out.println(f.getAbsolutePath()+" *** "+(String.format("%.3f", (double)f.length()/1024/1024))+" MB"); //displays path for a file
        	}catch(Exception e){
        		e.printStackTrace();
        	}
            return;
        }
        else{
            File dir_list[]=f.listFiles();  //lists all contents if a directory
            for (File t : dir_list)
                try{
               	if(!Files.readAttributes(t.toPath(), DosFileAttributes.class).isSystem())
                  list(t);  //calls list for each content of directory
                }catch(Exception e){
                	System.out.println();
                	System.out.println("Error:"+fsv.getSystemTypeDescription(t));
                	e.printStackTrace();
                }
        }
        
    }
	
}
